const config =  {
    db: "usuarios",
    port: 27017,
    host: "localhost",
}

module.exports = config;